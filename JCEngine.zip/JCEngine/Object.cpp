//#include "Object.h"
//
//Object::Object(string name)
//{
//	Component* Transform = new CTransform();
//	addComponent(Transform);
//
//	ob_name = name;
//
//	x_pos = 0;
//	y_pos = 0;
//	z_pos = 0;
//
//	x_scale = 0;
//	y_scale = 0;
//	z_scale = 0;
//
//}
//
//
//void Object::addChild(Object* child)
//{
//	childs.push_back(child);
//}
//void Object::removeChild(Object* child)
//{
//	list<Object*>::iterator src_child;
//	// find ���� ���� ��� �� �������� ����Ų��.
//	src_child = find(childs.begin(), childs.end(), child);
//
//	if (src_child != childs.end())
//	{
//		
//	}
//}
//void Object::addComponent(Component* component)
//{
//	components.push_back(component);
//}
//
//void Object::setPosition(float x, float y, float z)
//{
//	x_pos += x;
//	y_pos += y;
//	z_pos += z;
//
//	if (!childs.empty())
//	{
//		for (Object* i : childs)
//		{
//			i->setPosition(x, y, z);
//		}
//	}
//}
//void Object::setScale(float x, float y, float z)
//{
//	x_scale = x;
//	y_scale = y;
//	z_scale = z;
//}
//void Object::Awake()
//{
//
//}
//void Object::Start()
//{
//
//}
//void Object::Update()
//{
//
//}
//void Object::FixedUpdate()
//{
//
//}
