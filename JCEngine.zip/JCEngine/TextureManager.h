//#ifndef __TEXTURE_MANAGER_H__
//#define __TEXTURE_MANAGER_H__
//
//#include "SDL2-devel-2.0.16-VC/SDL2-2.0.16/include/sdl_ima"
//
//class TextureManager
//{
//
//};
//
//#endif