//#include "CCollision.h"
//
//void CCollision::Start()
//{
//
//}
//void CCollision::Update()
//{
//	if (CheckCollision())
//	{
//		// �浹 �̺�Ʈ �߻�
//	}
//}
//bool CCollision::CheckCollision()
//{
//
//}