#include "Scene.h"

void Scene::addObject(Object* object)
{
	objects.push_back(object);
}

void Scene::loop()
{
	for (Object* ob : objects)
	{
		ob->Update();
	}
}