#ifndef __SCENE_H__
#define __SCENE_H__ 

#include "Object.h"

#include <string>
#include <list>
using namespace std;

class Scene
{
public:
	void loop();
	
	void addObject(Object*);

private:
	list<Object*> objects;
};

#endif