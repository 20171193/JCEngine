#include "CTransform.h"

void CTransform::Start()
{

}

void CTransform::Update()
{

}

void CTransform::setPosition(float x, float y, float z)
{

}

void CTransform::setScale(float x, float y, float z)
{

}